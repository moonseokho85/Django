from django.apps import AppConfig


class AttendsConfig(AppConfig):
    name = 'attends'
